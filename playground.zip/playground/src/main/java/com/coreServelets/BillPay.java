package com.coreServelets;
import java.io.*;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.HealthCare.dao.HealthCareDatabaseActivityInserts;

@WebServlet("/BillPay")
public class BillPay extends HttpServlet {
	
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		
		String payType = request.getParameter("payType");
		String appId = request.getParameter("appId");
		String pFname = request.getParameter("pFname");
		String btn = request.getParameter("btn");
		String address = "/WEB-INF/doctorHomePage.jsp";
		System.out.println(appId);
		if(btn.equals("PayBill")) {
			if(!payType.equals("-1")) {
				HealthCareDatabaseActivityInserts dbact = new HealthCareDatabaseActivityInserts();
				try {
					dbact.UpdateBill(appId, payType);
					address = "/WEB-INF/BillSuccess.jsp";
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else {
				address = "/WEB-INF/doctorHomePage.jsp";
			}
		}
		request.getSession().setAttribute("pFname", pFname);
		request.getSession().setAttribute("appId", appId);
		RequestDispatcher dispatcher = request.getRequestDispatcher(address);
		dispatcher.forward(request,response);
	
	}
}


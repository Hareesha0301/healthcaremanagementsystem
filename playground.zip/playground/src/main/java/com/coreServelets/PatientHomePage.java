package com.coreServelets;
import java.io.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/PatientHomePage")
public class PatientHomePage extends HttpServlet {
	
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		
		String btn = request.getParameter("btn");
		String address = "";
		if(btn.equals("Patient")) {
			
			address = "/WEB-INF/PatientHomePage.jsp";
		}
		else if(btn.equals("support")) {
			address = "/WEB-INF/Support.jsp";
		}
		else {
			
			address = "/WEB-INF/Doctor.jsp";
			
		}
		RequestDispatcher dispatcher = request.getRequestDispatcher(address);
		dispatcher.forward(request,response);
	
	}
}


package com.coreServelets;
import java.io.*;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.HealthCare.dao.HealthCareDatabaseActivity;
import com.HealthCare.dao.HealthCareDatabaseActivityInserts;

@WebServlet("/AddDescToDB")
public class AddDescToDB extends HttpServlet {
	
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		
		String patId = request.getParameter("patientId");
		String des = request.getParameter("descriptionTextArea");
		String pres = request.getParameter("prescriptionTextArea");
		String assistantId = request.getParameter("assistant");
		String roomId = request.getParameter("room");
		String appId = request.getParameter("appointmentId");
		String payType = request.getParameter("billPaid");
		String isPaid = "";
		String amount = request.getParameter("bill");
		String docId = request.getParameter("docId");
		if(payType.equals("cash")) {
			isPaid = "y";
		}
		else {
			isPaid = "n";
		}
		String address = "";
		HealthCareDatabaseActivityInserts dbact = new HealthCareDatabaseActivityInserts(); 
		
		int a=0,b=0,c=0;
		try {
			a = dbact.UpdateApp(appId, pres, des);
			if(!roomId.equals("-1")) {
				c = dbact.UpdateRooms(roomId, patId);
			}
			else {
				b = 1;
			}
			if(!assistantId.equals("-1")) {
				b = dbact.UpdateAssist(assistantId, patId);
			}
			else {
				c = 1;
			}
			System.out.println(payType);
			if(payType.equals("cash")) {
				System.out.println("insert bill");
				dbact.insertBill(appId, patId, amount, isPaid , payType);
			}
			else if(payType.equals("online")){
				dbact.insertBill(appId, patId, amount, isPaid , "online");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		if(a>0 && b>0 && c>0) {
			
			address = "/WEB-INF/doctorHomePage.jsp";
			
		}
		request.setAttribute("dId", docId);
		RequestDispatcher dispatcher = request.getRequestDispatcher(address);
		dispatcher.forward(request,response);
	
	}
}


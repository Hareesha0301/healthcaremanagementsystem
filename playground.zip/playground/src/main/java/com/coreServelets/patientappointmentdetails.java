package com.coreServelets;
import java.io.*;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.HealthCare.dao.HealthCareDatabaseActivity;

@WebServlet("/patientappointmentdetails")
public class patientappointmentdetails extends HttpServlet {
	
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		
		String act = request.getParameter("btn");
		String address = "";
		
		if(act.equals("Home")) {
			address = "index.html";
		}
		else {
		String appId = request.getParameter("btn");
		String pFname = "";
		String pLname = "";
		
		HealthCareDatabaseActivity hdb = new HealthCareDatabaseActivity();
		System.out.print(appId);
		ResultSet rs = hdb.GetPatientAppDoctorDetails(appId);
		String assist = "no";
		String asst1="-1";
		String asst2="-1";
		String asst1Id = "-1";
		String asst2Id = "-1";
		String patientId = "";
		String isRoom = "yes";
		String room = "";
		String asst = "";
		String asstId = "";
		String fname = "";
		String desc = "";
		String dComm = "";
		String dPres = "";
		String isNew = "";
		String totalBill = "";
		String bill = "y";
		String isPaid = "";
		String pType = "";
		String docId = "";
		try {
			while(rs.next()) {
			pFname = rs.getString(9);
			pLname = rs.getString(10);
			docId = rs.getString(2);
			System.out.println("started while");
			totalBill = rs.getString(26);
			isPaid = rs.getString(28);
			pType = rs.getString(27);
			
			
			if(totalBill == null) {
				bill = "n";
			}
			else {
				if(isPaid.equals("y")) {
					isPaid = totalBill + " is paid " + "via " + pType;
				}
				else {
					isPaid = totalBill + "$ is yet to be paid online by the patient";
				}
			}
			patientId = rs.getString("PatientId");
			fname = rs.getString(9) + " " + rs.getString(10);
			desc = rs.getString(4);
			if(rs.getString(5) == null || rs.getString(5).isEmpty() || rs.getString(5).isBlank()) {
				isNew = "1";
				System.out.println("I am in isNew");
			}
			else {
				System.out.println("I am not in isNew");
				dComm = rs.getString(6);
				dPres = rs.getString(5);
			}
			if(rs.getString(15).length()>3 ) {
				System.out.println("found assist"+rs.getString(15));
				if(rs.getString(15).equals(rs.getString("PatientId")))
				{
					asstId = rs.getString(17);
					assist = "yes";
					asst =  rs.getString(20) + " "+ rs.getString(18) + " " +rs.getString(19)+" "+ "is assigned to the patient";
				}
				
			}
			if(asst1=="-1") {
				asst1 = rs.getString(18) + " " +rs.getString(19) + "is a " + rs.getString(20);
				asst1Id = rs.getString(17);
			}
			else {
				asst2 = rs.getString(18) + " " +rs.getString(19) + "is a " + rs.getString(20);
				asst2Id = rs.getString(17);
			}
			patientId = rs.getString(3);
			if(rs.getString(21) == null ) {
				isRoom = "no";
			}
			else {
				
				room = "Room " + rs.getString(21) + " is assigned to the patient";
			}
			}	
					
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		
		}
			address = "/WEB-INF/doctorInput.jsp";
			request.getSession().setAttribute("assist",assist);
			request.getSession().setAttribute("asstId",asstId);
			request.getSession().setAttribute("asst",asst);
			request.getSession().setAttribute("assist1",asst1);
			request.getSession().setAttribute("assist2",asst2);
			request.getSession().setAttribute("assist1Id",asst1Id);
			request.getSession().setAttribute("assist2Id",asst2Id);
			request.getSession().setAttribute("patId",patientId);
			request.getSession().setAttribute("isRoom",isRoom);
			request.getSession().setAttribute("room",room);
			request.getSession().setAttribute("appId",appId);
			request.getSession().setAttribute("fname",fname);
			request.getSession().setAttribute("desc",desc);
			request.getSession().setAttribute("isNew",isNew);
			request.getSession().setAttribute("dComm",dComm);
			request.getSession().setAttribute("dPres",dPres);
			request.getSession().setAttribute("totalBill",totalBill);
			request.getSession().setAttribute("bill",bill);
			request.getSession().setAttribute("isPaid",isPaid);
			request.getSession().setAttribute("pType",pType);
			request.getSession().setAttribute("docId",docId);
			
		}
		RequestDispatcher dispatcher = request.getRequestDispatcher(address);
		dispatcher.forward(request,response);
	
	}
}


package com.coreServelets;
import java.io.*;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.HealthCare.dao.HealthCareDatabaseActivity;

@WebServlet("/ValidateDoctor")
public class ValidateDoctor extends HttpServlet {
	
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		
		String email = request.getParameter("email");
		String pass = request.getParameter("pass");
		String address = "";
		String validatePass = "";
		String doctorId = "";
		
		ResultSet rs = null;
		HealthCareDatabaseActivity dbact = new HealthCareDatabaseActivity();
		try {
			System.out.println(email);
			rs = dbact.GetPasswordAndDoctorId(email);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(rs == null) {
			address = "/WEB-INF/doctorError.jsp";
		}
		else {
			
			try {
				while(rs.next()){
					System.out.println("id :"+rs.getString(2));
					System.out.println("pass :"+rs.getString(1));
					validatePass = rs.getString(1);
					doctorId = rs.getString(2);
					
				}
				
				if(validatePass.equals(pass)) {
					address = "/WEB-INF/doctorHomePage.jsp";
				}
				else {
					address = "/WEB-INF/doctorError.jsp";
				}
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("request id :" + doctorId);
			request.getSession().setAttribute("dId",doctorId);
		
			
			
		}
		
		
		RequestDispatcher dispatcher = request.getRequestDispatcher(address);
		dispatcher.forward(request,response);
	
	}
}


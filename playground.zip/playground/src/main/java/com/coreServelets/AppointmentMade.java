package com.coreServelets;
import java.io.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.HealthCare.dao.HealthCareDatabaseActivity;
import com.HealthCare.dao.HealthCareDatabaseActivityInserts;

@WebServlet("/AppointmentMade")
public class AppointmentMade extends HttpServlet {
	
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		
		int randomId = new Random().nextInt(90000000)+10000000;
		String appointmentId = "AP"+randomId;
		String patientId = "PAT"+randomId;
		String pFname = request.getParameter("pFname");
		String pLname = request.getParameter("pLname");
		String pAge = request.getParameter("pAge");
		String pEmail = request.getParameter("pEmail");
		String pPhone = request.getParameter("pPhone");
		String doctorId = request.getParameter("doctorId");
		String description = request.getParameter("description");
		String dFname = "";
		String dLname = "";
		String email = "";
		
		
		HealthCareDatabaseActivityInserts dbIns = new HealthCareDatabaseActivityInserts();
		HealthCareDatabaseActivity dbact = new HealthCareDatabaseActivity();
		int res1 = -1, res2 =-1;
		try {
			ResultSet rs3 = dbact.GetDoctorDetails(doctorId.trim());
			while(rs3.next()) {
				dFname = rs3.getString(2);
				dLname = rs3.getString(3);
				email = rs3.getString(7);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		try {
			res1 = dbIns.InsertNewPatient(patientId, pFname, pLname, pAge, pEmail, pPhone);
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		try {
			res2 = dbIns.InsertNewAppointment(appointmentId, patientId, doctorId, description);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(res1<1) {
			
			System.out.println("Patient not inserted");
		}
		if(res2<1) {
			
			System.out.println("Appointment not inserted");
		}
		String address = "/WEB-INF/AppointmentConfirmation.jsp";
		request.setAttribute("id",appointmentId);
		request.setAttribute("name",dFname + dLname);
		request.setAttribute("doctorIdnew", doctorId);
		request.setAttribute("dEmail", email);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher(address);
		dispatcher.forward(request,response);
	
	}
}


package com.coreServelets;
import java.io.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/NewAppointment")
public class NewAppointment extends HttpServlet {
	
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		
		String btn = request.getParameter("appointment");
		String address = "";
		
		
		if(btn.equals("view")) {
			
			address = "/WEB-INF/ValidatePatient.jsp";
			
		}
		else {
			
			address = "/WEB-INF/NewAppointment.jsp";
			
		}
		RequestDispatcher dispatcher = request.getRequestDispatcher(address);
		dispatcher.forward(request,response);
	
	}
}


package com.coreServelets;
import java.io.*;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.HealthCare.dao.HealthCareDatabaseActivity;

@WebServlet("/ValidatePatient")
public class ValidatePatient extends HttpServlet {
	
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		
		String appointid = request.getParameter("appointid");
		String fname = request.getParameter("fname");
		String address = "";
		HealthCareDatabaseActivity dbact = new HealthCareDatabaseActivity();
		String appId = "";
		String pName = "";
		String pEmail = "";
		String dName = "";
		String dEmail = "";
		String issue = "";
		String dComments = "";
		String pres = "";
		String room = "";
		String assistFname = "";
		String assistLname = "";
		String assist;
		String bill = "";
		String cardBill = "";
		String payType = "";
		String showPay = "n";
		String billType = "";
		String isPaid = "";
			int res = dbact.ValidatePatient(appointid, fname);
			if(res==1) {
				ResultSet rs = dbact.GetAllAppointmentDetails(appointid);
				try {
					while(rs.next()) {
						System.out.println("while");
						appId = rs.getString(1);
						pName = rs.getString(9) + " "+ rs.getString(10);
						pEmail = rs.getString(12);
						dName = rs.getString(15)+ " "+ rs.getString(16);
						dEmail = rs.getString(20);
						issue =	rs.getString(4);
						dComments= rs.getString(6);
						pres= rs.getString(5);
						room = rs.getString(21);
						assistFname = rs.getString(33);
						assistLname = rs.getString(34);				
						bill = rs.getString(29);
						payType = rs.getString(30);
						isPaid = rs.getString(31);
						
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				address = "/WEB-INF/ViewAppointment.jsp";
			}
			else {
				address = "/WEB-INF/patientError.jsp";
			}
		
		System.out.println("App ID" + appId);
		if(dComments.isBlank() || dComments.isEmpty()) {
			dComments = "Currently there are no comments by the doctor";
		}
		if(pres.isBlank() || pres.isEmpty()) {
			pres = "Currently there is no prescription added by the doctor";
		}
		if(room == null) {
			room = "Currently there is no room assigned to the doctor";
		}
		if(assistFname == null) {
			assist = "Currently there is no assistant added to the patient";
		}
		else {
			assist = assistFname + " " + assistLname;
		}
		if(bill == null || bill.isBlank()) {
			bill = "Currently there is no bill added for the patient";
		}
		else {
			if(!(isPaid.equals("y"))) {
				if(payType != "cash") {
					showPay = "y";
					cardBill = bill;
				}
			}		
		}
		
		request.getSession().setAttribute("appId",appId);
		request.getSession().setAttribute("pName",pName);
		request.getSession().setAttribute("pEmail",pEmail);
		request.getSession().setAttribute("dName",dName);
		request.getSession().setAttribute("dEmail", dEmail);
		request.getSession().setAttribute("issue",issue);
		request.getSession().setAttribute("dComments",dComments);
		request.getSession().setAttribute("pres",pres);
		request.getSession().setAttribute("room",room);
		request.getSession().setAttribute("assist",assist);
		request.getSession().setAttribute("bill",bill);
		request.getSession().setAttribute("showPay", showPay);
		request.getSession().setAttribute("cardBill", cardBill);
		request.getSession().setAttribute("pFname", fname);
		RequestDispatcher dispatcher = request.getRequestDispatcher(address);
		dispatcher.forward(request,response);
		
		
	
	}
}


package com.coreServelets;
import java.io.*;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.HealthCare.dao.HealthCareDatabaseActivityInserts;

@WebServlet("/Support")
public class Support extends HttpServlet {
	
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		
		String appId = request.getParameter("appId");
		String desc = request.getParameter("desc");
		String dateToday = java.time.LocalDate.now().toString();
		
		HealthCareDatabaseActivityInserts dbact = new HealthCareDatabaseActivityInserts();
		try {
			dbact.insertSupport(appId, desc, dateToday);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		RequestDispatcher dispatcher = request.getRequestDispatcher("index.html");
		dispatcher.forward(request,response);
	
	}
}


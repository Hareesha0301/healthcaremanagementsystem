package com.coreServelets;
import java.io.*; 
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.HealthCare.beans.Appointment;
import com.HealthCare.beans.Doctor;
import com.HealthCare.beans.Patient;

@WebServlet("/ViewDoctors")
public class ViewDoctors extends HttpServlet {
	
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		
		Patient patient = new Patient();
		Doctor doctor = new Doctor();
		Appointment app = new Appointment();
		patient.setFname(request.getParameter("fname"));
		patient.setLname(request.getParameter("lname"));
		patient.setAge(request.getParameter("age"));
		patient.setEmail(request.getParameter("email"));
		patient.setPhone(request.getParameter("phone"));
		app.setDescription(request.getParameter("descriptionTextArea"));
		doctor.setSpecialization(request.getParameter("specialization"));
		
		request.setAttribute("specialization", request.getParameter("specialization"));
		request.setAttribute("patient",patient);
		request.setAttribute("doctor", doctor);
		request.setAttribute("app", app);
		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/SubmitAppointment.jsp");
		dispatcher.forward(request,response);
	
	}
}


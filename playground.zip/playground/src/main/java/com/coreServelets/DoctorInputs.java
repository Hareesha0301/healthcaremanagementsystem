package com.coreServelets;
import java.io.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/DoctorInputs")
public class DoctorInputs extends HttpServlet {
	
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		
		String inp = request.getParameter("btn");
		String address = "";
		if(inp.equals("Home")) {
			address = "/WEB-INF/Doctor.jsp";
		}
		else {
			
		}
		RequestDispatcher dispatcher = request.getRequestDispatcher(address);
		dispatcher.forward(request,response);
	
	}
}


package com.HealthCare.dao;

import java.sql.*;
public class HealthCareDatabaseActivityInserts {

	public int InsertNewPatient(String patientId, String fname, String lname, String age, String email, String phone) throws SQLException {
		
		String username = "root";
		String password = "";
	//	String url = "jdbc:sqlserver://DESKTOP-03FKBEQ:1433;databaseName=HealthCareDb;trustServerCertificate=true;";
		String url = "jdbc:mysql://localhost:3306/healthcaredb";
		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(url,username,password);
			String insApp = "insert into patient values ('"+patientId+"','"+fname+"','"+lname+"','"+age+"','"+email+"','"+phone+"');";
			Statement stmt = con.createStatement();
			int result = stmt.executeUpdate(insApp);
			return result;
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
			return -1;
		}
		finally {
			con.close();
		}
	
		
	}
	
	public int InsertNewAppointment(String appointmentId, String patientId, String doctorId, String description) throws SQLException {
	
		String username = "root";
		String password = "";
	//	String url = "jdbc:sqlserver://DESKTOP-03FKBEQ:1433;databaseName=HealthCareDb;trustServerCertificate=true;";
		String url = "jdbc:mysql://localhost:3306/healthcaredb";
		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(url,username,password);
			String doctorIdnew = doctorId.trim();
			String insApp = "insert into appointment(AppointmentId,description,DoctorComments,DoctorId,IsClosed,PatientId,Prescription) values ('"+appointmentId+"','"+description+"' ,' ','"+doctorIdnew+"','0','"+patientId+"','');";
			Statement stmt = con.createStatement();
			int result = stmt.executeUpdate(insApp);
			return result;
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
			return -1;
		}
		finally {
			con.close();
		}
	
		
	}
	
	public int UpdateApp(String appId, String pr, String dc) throws SQLException {
		
		String appIdSt = appId.trim();
		String que = "Update appointment set Prescription = '"+pr+"',DoctorComments = '"+dc+"' where AppointmentId = '"+appIdSt+"';";
		String username = "root";
		String password = "";
	//	String url = "jdbc:sqlserver://DESKTOP-03FKBEQ:1433;databaseName=HealthCareDb;trustServerCertificate=true;";
		String url = "jdbc:mysql://localhost:3306/healthcaredb";
		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(url,username,password);
			Statement stmt = con.createStatement();
			int result = stmt.executeUpdate(que);
			return result;
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
			return -1;
		}
		finally {
			con.close();
		}
	}
	
public int UpdateAssist(String assist, String pt) throws SQLException {
		
		String que = "Update assistantassign set PatientId = '"+pt+"' where AssistantId = '"+assist+"';";
		String username = "root";
		String password = "";
	//	String url = "jdbc:sqlserver://DESKTOP-03FKBEQ:1433;databaseName=HealthCareDb;trustServerCertificate=true;";
		String url = "jdbc:mysql://localhost:3306/healthcaredb";
		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(url,username,password);
			Statement stmt = con.createStatement();
			int result = stmt.executeUpdate(que);
			return result;
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
			return -1;
		}
		finally {
			con.close();
		}
	}
public void UpdateBill(String appId, String Btype) throws SQLException {
	
	String appIds = appId.trim();
	String que = "Update bill set IsPaid = 'y' , PaymentType = '"+Btype+"' where AppointmentId = '"+appIds+"';";
	System.out.println(que);
	String username = "root";
	String password = "";
//	String url = "jdbc:sqlserver://DESKTOP-03FKBEQ:1433;databaseName=HealthCareDb;trustServerCertificate=true;";
	String url = "jdbc:mysql://localhost:3306/healthcaredb";
	Connection con = null;
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		con = DriverManager.getConnection(url,username,password);
		Statement stmt = con.createStatement();
		stmt.executeUpdate(que);
	}
	catch(Exception e) {
		System.out.println(e.getMessage());
	}
	finally {
		con.close();
	}
}
public int UpdateRooms(String room, String pt) throws SQLException {
	
	int rn = Integer.parseInt(room);
	String que = "insert into rooms values("+rn+",'"+pt+"');";
	String username = "root";
	String password = "";
//	String url = "jdbc:sqlserver://DESKTOP-03FKBEQ:1433;databaseName=HealthCareDb;trustServerCertificate=true;";
	String url = "jdbc:mysql://localhost:3306/healthcaredb";
	Connection con = null;
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		con = DriverManager.getConnection(url,username,password);
		Statement stmt = con.createStatement();
		int result = stmt.executeUpdate(que);
		return result;
	}
	catch(Exception e) {
		System.out.println(e.getMessage());
		return -1;
	}
	finally {
		con.close();
	}
}

public void insertBill(String appId, String pId, String amount, String isPaid, String payType) throws SQLException {
	
	String apId = appId.trim();
	System.out.println("Paytype" + payType);
	String que = "insert into bill (PatientId,AppointmentId,Amount,PaymentType,IsPaid) values('"+pId+"','"+apId+"','"+amount+"','"+payType+"','"+isPaid+"');";
	System.out.println(que);
	String username = "root";
	String password = "";
//	String url = "jdbc:sqlserver://DESKTOP-03FKBEQ:1433;databaseName=HealthCareDb;trustServerCertificate=true;";
	String url = "jdbc:mysql://localhost:3306/healthcaredb";
	Connection con = null;
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		con = DriverManager.getConnection(url,username,password);
		Statement stmt = con.createStatement();
		int result = stmt.executeUpdate(que);
	}
	catch(Exception e) {
		System.out.println(e.getMessage());
	}
	finally {
		con.close();
	}
}

public void insertSupport(String appId, String desc, String dat) throws SQLException {
	
	
	String que = "insert into support(AppointmentID,Description,Date) values('"+appId+"','"+desc+"','"+dat+"');";
	String username = "root";
	String password = "";
//	String url = "jdbc:sqlserver://DESKTOP-03FKBEQ:1433;databaseName=HealthCareDb;trustServerCertificate=true;";
	String url = "jdbc:mysql://localhost:3306/healthcaredb";
	Connection con = null;
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		con = DriverManager.getConnection(url,username,password);
		Statement stmt = con.createStatement();
		stmt.executeUpdate(que);
	}
	catch(Exception e) {
		System.out.println(e.getMessage());
	}
	finally {
		con.close();
	}
}
		

}

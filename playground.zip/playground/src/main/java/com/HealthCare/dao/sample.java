package com.HealthCare.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class sample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String username = "root";
		String password = "";
		String url = "jdbc:mysql://localhost:3306/healthcaredb";
		
		try {
			
			Connection con = DriverManager.getConnection(url,username,password);
			String sel = "select * from doctor ;";
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sel);
			}
		catch(Exception e) {
			System.out.println(e.getMessage());
		
		}
		
		
	}

}

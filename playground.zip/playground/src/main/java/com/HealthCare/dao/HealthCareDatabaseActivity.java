package com.HealthCare.dao;

import java.sql.*;
public class HealthCareDatabaseActivity {

	public ResultSet GetAllDoctors(String specialization) throws SQLException {
		
		System.out.println(specialization);
		String username = "root";
		String password = "";
	//	String url = "jdbc:sqlserver://DESKTOP-03FKBEQ:1433;databaseName=HealthCareDb;trustServerCertificate=true;";
		String url = "jdbc:mysql://localhost:3306/healthcaredb";
		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("In try");
			con = DriverManager.getConnection(url,username,password);
			String sel = "select * from doctor where specialization = '"+specialization+"' ;";
			System.out.println(sel);
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sel);
			return rs;
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
			return null;
		}
	}
		
		public ResultSet GetPasswordAndDoctorId(String email) throws SQLException {
			
			String username = "root";
			String password = "";
			String url = "jdbc:mysql://localhost:3306/healthcaredb";
			Connection con = null;
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				con = DriverManager.getConnection(url,username,password);
				String sel = "select password,ID from doctor where email = '"+email+"' ;";
				System.out.println(sel);
				Statement stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery(sel);
				return rs;
			}
			catch(Exception e) {
				System.out.println(e.getMessage());
				return null;
			}
	}
		
		public ResultSet GetPatients(String dId) throws SQLException {
			
			String username = "root";
			String password = "";
			String url = "jdbc:mysql://localhost:3306/healthcaredb";
			Connection con = null;
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				con = DriverManager.getConnection(url,username,password);
				String sel = "SELECT * FROM appointment a join patient p on a.PatientId = p.ID where a.doctorId = '"+dId+"' ;";
				System.out.println(sel);
				Statement stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery(sel);
				return rs;
			}
			catch(Exception e) {
				System.out.println(e.getMessage());
				return null;
			}
	}
		
		public ResultSet GetPatientAppDoctorDetails(String appId) {
			
			String username = "root";
			String password = "";
			String url = "jdbc:mysql://localhost:3306/healthcaredb";
			Connection con = null;
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				con = DriverManager.getConnection(url,username,password);
				String trimApp = appId.trim();
				String sel = "SELECT * FROM appointment a join patient p on a.PatientId = p.ID join assistantassign ag on a.DoctorId = ag.DoctorId join assistant assis on assis.Id = ag.assistantId left outer join rooms r on r.PatientId = a.PatientId left outer join bill b on b.AppointmentId = a.AppointmentId where a.AppointmentId = '"+trimApp+"';";
				System.out.println(sel);
				Statement stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery(sel);
				return rs;
			}
			catch(Exception e) {
				System.out.println(e.getMessage());
				return null;
			}
			
		}
	
		public int ValidatePatient(String appId,String fname) {
			
			String username = "root";
			String password = "";
			String url = "jdbc:mysql://localhost:3306/healthcaredb";
			Connection con = null;
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				con = DriverManager.getConnection(url,username,password);
				String sel = "SELECT p.FirstName FROM appointment a join patient p on a.PatientId = p.Id where a.AppointmentId = '"+appId+"';";
				System.out.println(sel);
				Statement stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery(sel);
				String firstName = "";
				while(rs.next()) {
					firstName = rs.getString(1);
				}
				System.out.println(firstName);
				if(firstName.equals(fname)) {
					return 1;
				}
					
					else {
						return 0;
					}
			}
			catch(Exception e) {
				System.out.println(e.getMessage());
				return -1;
			}
			
		}
		
		
		public ResultSet GetAllAppointmentDetails(String appId) {
			
			String username = "root";
			String password = "";
			String url = "jdbc:mysql://localhost:3306/healthcaredb";
			Connection con = null;
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				con = DriverManager.getConnection(url,username,password);
				System.out.println(appId);
				//String sel = "SELECT p.FirstName FROM appointment a join patient p on a.PatientId = p.Id where a.AppointmentId = '"+appId+"';";
				String sel = "SELECT * from appointment a join patient p on a.PatientId = p.ID join doctor d on a.DoctorId = d.ID left outer join rooms r on p.ID = r.PatientId left outer join assistantassign assign on assign.PatientId = a.PatientId left outer join bill b on b.AppointmentId = a.AppointmentId left outer join assistant ass on ass.ID = assign.AssistantId where a.AppointmentId = '"+appId+"';";
				System.out.println(sel);
				Statement stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery(sel);
				return rs;
			}
			catch(Exception e) {
				System.out.println(e.getMessage());
				return null;
			}
			
		}
		

		public ResultSet GetDoctorDetails(String dId) {
			
			String username = "root";
			String password = "";
			String url = "jdbc:mysql://localhost:3306/healthcaredb";
			Connection con = null;
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				con = DriverManager.getConnection(url,username,password);
				//String sel = "SELECT p.FirstName FROM appointment a join patient p on a.PatientId = p.Id where a.AppointmentId = '"+appId+"';";
				String sel = "SELECT * from doctor where ID = '"+dId+"';";
				System.out.println(sel);
				Statement stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery(sel);
				return rs;
			}
			catch(Exception e) {
				System.out.println(e.getMessage());
				return null;
			}
			
		}

		
		
}

package com.HealthCare.beans;

import java.util.Random;

public class Appointment {
	
	private String appointmentId;
	private String doctorId;
	private String patientId;
	private String description;
	private String presciption;
	private String isClosed;
	private String doctorComments;
	public String getAppointmentId() {
		return appointmentId;
	}
	public void setAppointmentId(String appointmentId) {
		this.appointmentId = appointmentId;
	}
	public String getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(String doctorId) {
		this.doctorId = doctorId;
	}
	public String getPatientId() {
		return patientId;
	}
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getPresciption() {
		return presciption;
	}
	public void setPresciption(String presciption) {
		this.presciption = presciption;
	}
	public String getIsClosed() {
		return isClosed;
	}
	public void setIsClosed(String isClosed) {
		this.isClosed = isClosed;
	}
	public String getDoctorComments() {
		return doctorComments;
	}
	public void setDoctorComments(String doctorComments) {
		this.doctorComments = doctorComments;
	}
	

}
